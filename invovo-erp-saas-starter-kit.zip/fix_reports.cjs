const fs = require('fs');

// 1. Fix Reports.jsx
let repCtx = fs.readFileSync('src/pages/Reports.jsx', 'utf8');

repCtx = repCtx.replace(
  `  const fetchFinancials = async () => {
    if (!activeShopId || role !== 'shop_owner') {
      setLoading(false);
      return;
    }
    
    try {
      setLoading(true);

      // Fetch Shop Settings/Name first for proper print heading
      const settingsCached = localStorage.getItem(\`invovo_erp_settings_cache_\${activeShopId}\`);`,
  `  const fetchFinancials = async () => {
    const targetShopId = activeShopId || localStorage.getItem('current_shop_id') || 'a0000000-0000-0000-0000-000000000001';
    
    if (!targetShopId) {
      setLoading(false);
      return;
    }
    
    try {
      setLoading(true);

      // Fetch Shop Settings/Name first for proper print heading
      const settingsCached = localStorage.getItem(\`invovo_erp_settings_cache_\${targetShopId}\`);`
);
fs.writeFileSync('src/pages/Reports.jsx', repCtx);

// 2. Fix vite.config.js
let viteCtx = fs.readFileSync('vite.config.js', 'utf8');
viteCtx = viteCtx.replace(/pwa-192x192\.png/g, 'icon-192.png');
viteCtx = viteCtx.replace(/pwa-512x512\.png/g, 'icon-512.png');
fs.writeFileSync('vite.config.js', viteCtx);

console.log('Fixed Reports and PWA icons.');
