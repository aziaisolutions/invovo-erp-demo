const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(function(file) {
    file = dir + '/' + file;
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else {
      results.push(file);
    }
  });
  return results;
}

const files = walk('src').filter(f => f.endsWith('.js') || f.endsWith('.jsx'));

console.log("=== SCAN RESULTS ===");
files.forEach(file => {
  const content = fs.readFileSync(file, 'utf8');
  const lines = content.split('\n');
  lines.forEach((line, i) => {
    if (line.match(/alert\(.*Failed to (fetch|load).*\)/i) || line.match(/alert\(.*(financial|data).*\)/i)) {
      console.log(`${file}:${i + 1} - ${line.trim()}`);
    }
  });
});
