const fs = require('fs');

let f = fs.readFileSync('src/pages/Reports.jsx', 'utf8');

f = f.replace(/console\.error\(err\);\s*alert\('Failed to fetch financial data\.'\);/g, 
  'console.error("Financial Data Fetch Notice:", err);\n      setTransactions([]);\n      setExpenses([]);\n      setInvoices([]);'
);

fs.writeFileSync('src/pages/Reports.jsx', f);
console.log('Fixed Reports.jsx with regex');
